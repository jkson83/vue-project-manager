<template>
	<footer class="asideFooter">
		<!-- <div class="footer_logo">
			<img src="@/assets/images/common/dplanex_black_logo.png" alt="DPLANEX logo">
		</div> -->
		<ul class="menuList">
			<li v-for="(item, index) in menuData" :key="index">
				<router-link :to="item.path">
					<span>{{ item.name }}</span>
				</router-link>
			</li>
		</ul>
		<div class="copy">
			<p>주식회사 디플래닉스</p>
			<p>사업자등록번호 : 626-88-02259</p>
			<p>주소: 서울특별시 서초구 강남대로 465, 교보타워 B동4층</p>
		</div>
	</footer>
</template>

<script setup>
import { ref } from 'vue'

const menuData = ref([
	{ name: "이용약관", path: "/publishing/FE_MB/FE_MB_TC_01" },
	{ name: "개인정보처리방침", path: "/publishing/FE_MB/FE_MB_TC_02" },
])
</script>

