<template>
	<aside class="lnbArea">
		<div class="lnbAreaWrap">
			<div class="logo">
				<h1>
					<router-link :to="{ name: 'FE_Common_UI_Main' }">
						<span class="c1">그룹데이터 포털</span>
						<span class="c2"><em>powered by DPLANEX</em></span>
					</router-link>
				</h1>
			</div>
			<nav class="asideNav">
				<ul class="menuList">
					<li v-for="(menu, index) in menuData" :key="index" @click="handleMenuClick(menu.id)">
						<router-link :to="menu.path">
							<span>{{ menu.name }}</span>
						</router-link>
					</li>
				</ul>
			</nav>
			<AsideFooter />
		</div>
	</aside>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import AsideFooter from '@/components/common/AsideFooter'

const router = useRouter();
const menuData = ref([
	{ id: "FE_DS", name: "대시보드", path: "/publishing/FE_DS" },
	{ id: "FE_RP", name: "보고서", path: "/publishing/FE_RP" },
	{ id: "FE_DO", name: "데이터 현황", path: "/publishing/FE_DO" },
	{ id: "FE_CM", name: "커뮤니티", path: "/publishing/FE_CM" },
	{ id: "FE_AE", name: "분석 환경", path: "/publishing/FE_AE" },
	{ id: "Guide", name: "가이드", path: "/publishing/Guide" },
])

function handleMenuClick(menuId) {
	router.push({ name: menuId })
}
</script>
