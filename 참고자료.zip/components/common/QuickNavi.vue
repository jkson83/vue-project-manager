<template>
	<aside class="quickArea">
		<nav class="quickNav">
			<div class="quickNavWrap">
				<div class="quickHead">
					<a href="javascript:void(0);" class="btnMy">
						<p class="ci"><!-- BD061 -->
							<!-- <span class="imgArea">
								<img src="@/assets/images/temp/quick_ci.png" alt="교보생명 CI">
							</span> -->
							<span class="txtArea">
								<em>교보생명</em>
								<!-- <em>라이프<br>플래닛</em> -->
							</span>
						</p>
						<p class="name"><span>김교보</span><em>님</em></p>
					</a>
				</div>
				<ul class="menuList">
					<li>
						<a href="javascript:void(0);" class="btnIcon"><span>알림함</span>
							<span class="noti"><em class="blind">New Alarm</em></span><!-- 알림 없을경우: Line 삭제 -->
						</a>
					</li>
					<li><a href="javascript:void(0);" class="btnIcon"><span>결재함</span></a></li>
					<li><a href="javascript:void(0);" class="btnIcon"><span>내문서</span></a></li>
					<!-- <li><a href="javascript:void(0);" class="btnIcon"><span>문의함</span></a></li> -->
					<li><a href="javascript:void(0);" class="btnIcon"><span>이용가이드</span></a></li>
					<li><a href="javascript:void(0);" class="btnIcon"><span>태블로</span></a></li>
					<li><a href="javascript:void(0);" class="btnIcon"><span>즐겨찾기</span></a></li>
				</ul>
				<ul class="quickFooter">
					<li><a href="javascript:void(0);" class="btnIcon btnAdmin"><span>관리자</span></a></li>
					<li><a href="javascript:void(0);" class="btnIcon btnLogout"><span>로그아웃</span></a></li>
				</ul>
			</div>
		</nav>
	</aside>
</template>

<script setup>
// import { onMounted, onUnmounted } from 'vue';

// onMounted(() => {
// 	const quickNav = document.querySelector('.quickNav');
// 	const containerArea = document.querySelector('.containerArea');
// 	let lastScrollTop = 0;

// 	const handleScroll = () => {
// 		const scrollTop = containerArea.scrollTop;
// 		const offsetTop = Math.max(0, scrollTop);
// 		quickNav.style.transform = `translateY(${offsetTop}px)`;
// 		lastScrollTop = scrollTop;
// 	};

// 	containerArea.addEventListener('scroll', handleScroll);

// 	onUnmounted(() => {
// 		containerArea.removeEventListener('scroll', handleScroll);
// 	});
// });
</script>
