<template>
	<div v-if="menuData.length" class="topNavi">
		<ul>
			<li v-for="menu in menuData" :key="menu.name">
				<router-link :to="{ name: menu.id }" class="btn" :class="{ active: $route.name === menu.id }">
					<span>{{ menu.name }}</span>
				</router-link>	
			</li>
		</ul>
	</div>
</template>

<script setup>
import { ref, watch } from 'vue'

const props = defineProps({
	parentRouteId: {
		type: String,
		required: true
	}
});

const menuData = ref([]);
const allMenus = {
	//약관 및 정책
	FE_MB_TEARMS: [
		{id: "FE_MB_TC_01",  name: "이용 약관" },
		{id: "FE_MB_TC_02",  name: "개인정보처리방침" },
		// {id: "FE_MB_TC_03",  name: "보안서약서" },
	],

	//대시보드
	FE_DS: [
		{id: "FE_DS_GC_01",  name: "디지털 행태" },
		{id: "",  name: "데이터 집계" },
	],

	//보고서
	FE_RP: [
		{id: "FE_RP_CB_01",  name: "가명 결합 보고서" },
		{id: "FE_RP_AN_01",  name: "분석 보고서" },
	],

	//데이터 현황
	FE_DO: [
		{id: "FE_DO_DS_01",  name: "보유 데이터 조회" },
		{id: "FE_DO_MD_01",  name: "메타 데이터 조회" },
		{id: "FE_DO_CV_01",  name: "동의 현황" },
	],

	//커뮤니티
	FE_CM: [
		{id: "FE_CM_BD_01",  name: "자료실" },
		{id: "FE_CM_NT_01",  name: "공지사항" },
		{id: "FE_CM_FAQ_01",  name: "FAQ" },
	],

	//분석 환경
	FE_AE: [
		{id: "FE_AE_IF_01_1",  name: "프로젝트 조회" },
		{id: "FE_AE_DA_01",  name: "데이터 결재 관리" },
	],


	//분석 환경
	FE_MY: [
		{id: "FE_MY_PA_01",  name: "내 정보" },
		{id: "",  name: "서비스 결재 관리" },
	],

	//포털 서비스 가이드
	FE_ETC: [
		{id: "FE_ETC_GD_01", name: "포털이용가이드" },
		{id: "",  name: "용어 정리" },
	],

	//Guide
	Guide: [
		{ id: "GuideComponent", name: "Component" },
		{ id: "GuideForm", name: "Form" },
		{ id: "GuideButton", name: "Button" },
		{ id: "GuideTable", name: "Table" },
		{ id: "GuideTableWrite", name: "Table Write" },
		{ id: "GuideSearchBox", name: "SearchBox" },
		{ id: "GuideModal", name: "Modal" },
		{ id: "GuideAlertConfirm", name: "Alert & Confirm" },
		{ id: "GuideAccordion", name: "Accordion" },
		{ id: "GuideTab", name: "Tab" },
		// { id: "TemplateModal_pub", name: "TemplateModal_pub" },
	],
};

// Header 메뉴 클릭시 Aside 메뉴 변경
watch(() => props.parentRouteId, (newRouteId) => {
	menuData.value = allMenus[newRouteId] || []
}, { immediate: true });
</script>
