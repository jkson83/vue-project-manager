<template>
	<div class="containerWrap">
		<AsideNavi />
		<div :class="['containerArea', { sticky: isSticky }]" ref="containerArea">
			<div class="contentWrap">
				<div class="contentInner">
					<div class="topNavBg" :style="{ height: topNavBgHeight + 'px' }"></div>
					<TopNavi :parentRouteId="parentRouteId" />
					<router-view></router-view>
				</div>	
			</div>
			<QuickNavi />
		</div>
	</div>
</template>

<script setup>
import { ref, watch, onMounted, onUnmounted, nextTick } from 'vue'
import { useRoute } from 'vue-router'
import AsideNavi from '@/components/common/AsideNavi.vue'
import TopNavi from '@/components/common/TopNavi.vue'
import QuickNavi from '@/components/common/QuickNavi.vue'

const route = useRoute()
const parentRouteId = ref(route.matched[0]?.name)

watch(route, (newRoute) => {
  parentRouteId.value = newRoute.matched[0]?.name
  updateTopNavBgHeight()
});

//sticky
const isSticky = ref(false)
const containerArea = ref(null)
const topNavBgHeight = ref(0)
let lastScrollTop = 0

const handleScroll = () => {
  const contAreaPos = document.querySelector('.contArea')?.offsetTop || 0
  const currentScrollTop = containerArea.value.scrollTop

  if (currentScrollTop > contAreaPos) {
    if (currentScrollTop < lastScrollTop) {
      isSticky.value = true // 스크롤 업
    } else {
      isSticky.value = false // 스크롤 다운
    }
  } else {
    isSticky.value = false
  }

  lastScrollTop = currentScrollTop
};

const updateTopNavBgHeight = () => {
  nextTick(() => {
    const topNaviHeight = document.querySelector('.topNavi')?.offsetHeight || 0
    const menu3DepthWrapper = document.querySelector('.menu3DepthWrapper')?.offsetHeight || 0
    topNavBgHeight.value = menu3DepthWrapper + topNaviHeight + 64
  })
}

onMounted(() => {
  containerArea.value.addEventListener('scroll', handleScroll)
  updateTopNavBgHeight()
  window.addEventListener('resize', updateTopNavBgHeight)
})

onUnmounted(() => {
  if (containerArea.value) {
    containerArea.value.removeEventListener('scroll', handleScroll)
  }
  window.removeEventListener('resize', updateTopNavBgHeight)
})
</script>