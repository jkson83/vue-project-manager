<template>
	<div class="login">
		<div class="loginWrap">
			<div class="loginLogo">
				<h1><em>KYOBO</em>그룹데이터 포털</h1>
				<p class="dplnex"><em>powered by DPLANEX</em></p>
				<p class="slogan">BI 인사이트로 스마트 비즈니스를 실현하다</p>
			</div>		
			<div class="loginBox">
				<router-view></router-view>
			</div>
		</div>
	</div>
</template>

<script setup>

</script>