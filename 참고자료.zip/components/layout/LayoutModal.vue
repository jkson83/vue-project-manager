<template>
	<Teleport to=".modalLayout">
		<div 
			:class="`modalWrap ${modalType}`"
			:id="props.modalId"
			role="dialog"
			aria-modal="true"
			:aria-labelledby="labelId"
			:aria-describedby="`${props.modalId}_desc`"
			tabindex="-1"
		>
			<div class="modalDialog">
				<div :class="`modalContent ${modalSize}`" role="document">
					<div class="modalHeader" v-if="$slots.header">
						<slot name="header"></slot>
					</div>

					<div :id="`${props.modalId}_desc`" class="modalBody">
						<div class="modalBodyWrap">
							<slot name="body"></slot>
						</div>
					</div>
					<div class="modalFooter" v-if="$slots.footer">
						<slot name="footer"></slot>
					</div>

					<button type="button" class="modalClose" @click="emit('close')">
						<span class="blind">닫기</span>
					</button>
				</div>
			</div>
		</div>
	</Teleport>
</template>

<script setup>
import { onMounted } from 'vue'

const props = defineProps({
	modalId: { type: String },
	modalType: { type: String },
	modalSize: { type: String },
	labelId: { type: String }
});

const emit = defineEmits(['close']);

// 웹접근성
const accessibility = () => {
	let modal = document.querySelector(`#${props.modalId}`)
	let focusableEls = modal.querySelectorAll(
		'[href], button, select, input, textarea, [tabindex]:not([tabindex="-1"])'
	);

	focusableEls.forEach((el) => {
		el.setAttribute('tabindex', -1)
	});
};

onMounted(() => {
	accessibility()
});
</script>