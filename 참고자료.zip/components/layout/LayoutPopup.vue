<template>
	<div class="popupLayout">
		<div class="popupContainer">
		<router-view></router-view>
		</div>
	</div>
</template>

<script setup>

</script>
