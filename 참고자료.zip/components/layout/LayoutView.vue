<template>
	<div class="containerWrap">
		<AsideNavi />
		<div class="containerArea">
			<div class="contentWrap">
				<div class="contentInner">
					<router-view></router-view>
				</div>	
			</div>
			<QuickNavi />
		</div>
	</div>
</template>

<script setup>
import AsideNavi from '@/components/common/AsideNavi.vue'
import QuickNavi from '@/components/common/QuickNavi.vue'
</script>