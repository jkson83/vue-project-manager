
<template>
	<button type="button" class="btnFavorite" :class="{ active: isFavorite }" @click="toggleFavorite"><span>즐겨찾기</span></button>
</template>

<script setup>
import { ref } from 'vue'
const isFavorite = ref(false)


function toggleFavorite() {
	isFavorite.value = !isFavorite.value
}
</script>