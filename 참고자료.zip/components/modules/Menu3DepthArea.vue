<template>
	<div class="menu3DepthArea">
		<ul>
			<li v-for="(item, index) in items" :key="index">
				<button type="button" class="btn" :class="{ active: activeButton === index }" @click="clickHandler(index, item)">
					<span>{{ item }}</span>
				</button>
			</li>
		</ul>
	</div>
</template>

<script setup>
import { ref, defineProps, defineEmits, watch } from 'vue'

const props = defineProps({
	items: {
		type: Array,
		required: true
	},
	activeButton: {
		type: Number,
		default: 0
	}
})

const emits = defineEmits(['update:activeButton', 'clickButton'])
const activeButton = ref(props.activeButton)

watch(() => props.activeButton, (newValue) => {
	activeButton.value = newValue
}, { immediate: true }) // 초기 활성화 값을 즉시 반영

function clickHandler(index) {
	activeButton.value = index
	emits('update:activeButton', index)
	emits('clickButton', index)
}
</script>
