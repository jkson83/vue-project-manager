<template>
	<div :class="['permission', $attrs.class]">
		<div class="permissionWrap">
			<div class="titleArea">
				<h4 class="title ">{{ props.data.title }}</h4>
			</div>
			<div class="body">
				<div v-if="!$attrs.class || $attrs.class === ''">
					<span class="name">{{ props.data.name }}</span>님, 
					<span class="cate">{{ props.data.cate }}</span> 이용 권한이 없습니다. <br>
					이용 권한이 있는 사용자에게 노출됩니다. <br>
					이용이 필요하신 경우 <span class="cate">{{ props.data.cate }}</span> 이용 권한을 신청해주세요.
				</div>
				<div v-else>
					이용 권한 신청되어 승인 대기 중입니다. <br> 승인 진행 및 결과는 알림함으로 안내드립니다
				</div>
			</div>
			<div class="btnArea">
				<button type="button" class="btn sky" :disabled="$attrs.class"><span>이용 권한 신청</span></button>
				<button type="button" class="btn sky"><span>권한 신청 모두 보기</span></button>
			</div>
		</div>
		<div class="permissionBg"></div>
	</div>
</template>

<script setup>
import { defineProps } from 'vue'

const props = defineProps({
	data: Object
})
</script>