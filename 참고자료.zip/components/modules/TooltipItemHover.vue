<script setup>
import { ref, nextTick, onMounted, onBeforeUnmount } from 'vue';

const props = defineProps({
	id: { type: String },
	tipTitle: { type: String },
	isOpen: { type: Boolean, default: false }
});

const tooltipOpen = ref(false);

// tooltip show
function tipShow(e) {
	if (!tooltipOpen.value) {
		tooltipOpen.value = true;
		
		nextTick(() => {
			let winH = window.innerHeight;
			let scrT = window.scrollY;
			let tipTrigger = e.target;
			let tipT = tipTrigger.getBoundingClientRect().top;
			let tipH = tipTrigger.getBoundingClientRect().height;
			let tipL = tipTrigger.getBoundingClientRect().left;
			let tipW = tipTrigger.getBoundingClientRect().width;

			let tipObj = document.querySelector(`#${props.id}-tooltip`);
			let tipObjH = tipObj.getBoundingClientRect().height;
			let tipObjW = tipObj.getBoundingClientRect().width;

			let tipObjPos = tipT + tipH + tipObjH;
			let tipObjL = tipL + (tipW / 2) - (tipObjW / 2); // 툴팁을 가운데 정렬
			let tipObjT;

			tipObj.style.left = `${tipObjL}px`;

			if (winH > tipObjPos) {
					tipObj.classList.remove('top');

					tipObjT = tipT + tipH + scrT;
					tipObj.style.top = `${tipObjT + 6}px`;
			} else {
					tipObj.classList.add('top');

					tipObjT = tipT - tipObjH + scrT;
					tipObj.style.top = `${tipObjT - 14}px`;
			}

			// // 포커스를 name="tooltipClose" 요소로 이동
			// const closeButton = document.querySelector('#tooltipClose');
			// if(closeButton){
			// 	closeButton.focus();
			// }else {
			// 	console.error('Element with name "tooltipClose" not found');
			// }
		});		
	}
}

// tooltip hide
function tipHide() {
	if (tooltipOpen.value) {
		tooltipOpen.value = false;
		// const movefocus = document.querySelector('.tooltip-trigger');
		// movefocus.focus();
	}
}

function handleScroll() {
	if (tooltipOpen.value) {
		tipHide();
	}
}

onMounted(() => {
	const containerArea = document.querySelector('.containerArea');
	const tableList = document.querySelector('.tableList');

	if (containerArea) {
		containerArea.addEventListener('scroll', handleScroll);
	}

	if (tableList) {
		tableList.addEventListener('scroll', handleScroll);
	}
});

onBeforeUnmount(() => {
	const containerArea = document.querySelector('.containerArea');
	const tableList = document.querySelector('.tableList');

	if (containerArea) {
		containerArea.removeEventListener('scroll', handleScroll);
	}

	if (tableList) {
		tableList.removeEventListener('scroll', handleScroll);
	}
});
</script>

<template>
	<div class="tooltip hoverType">
		<button
			type="button"
			:id="props.id"
			class="tooltip-trigger"
			:aria-describedby="`${props.id}-tooltip`"
			@mouseover="tipShow"
			@mouseout="tipHide"
		>
			<span class="title">{{ props.tipTitle }}</span>
		</button>
		<teleport to="body">
			<div v-if="tooltipOpen" :id="`${props.id}-tooltip`" class="tooltip-wrap hoverType" role="tooltip">
				<!-- <slot></slot> -->
				{{ props.tipTitle }}
				<!-- <a href="javascript:void(0);" @click="tipHide" id="tooltipClose"><span class="close-btn"><span class="blind">닫기</span></span></a> -->
			</div>
		</teleport>
	</div>
</template>
