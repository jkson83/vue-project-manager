// import { createRouter, createWebHistory } from 'vue-router'
import { createRouter, createWebHashHistory } from 'vue-router' // [10/31] BD003: pub 테스트용 변경
import publishingRoutes from '@/router/modules/publishing'
import sampleRoutes from '@/router/modules/sample'  

const routes = [
  { 
    path: '/', 
    alias: '/main',
    name: 'main',
    component: () => import('@/views/Main'),
    meta: { 
      auth: true,
      logging: true,
      pageName: '메인',
    },    
  },
  ...publishingRoutes,
  ...sampleRoutes,
  { 
    path: '/:pathMatch(.*)*', 
    redirect: { name: 'main' }
  },
]

const router = createRouter({
  // history: createWebHistory(import.meta.env.BASE_URL),
  // history: createWebHistory(),
  history: createWebHashHistory(), // [10/31] BD003: pub 테스트용 변경
  routes,
  scrollBehavior(){
    return { top: 0 }
  },
})


// const canUserAccess = (to) => {
//   const auth = to.meta.auth
//   if(!auth) {
//     return true
//   }

//   return false
// }
// 
// router.beforeEach( (to, from, next) => {
//   console.log("router.beforeEach", to, from)
  
//   const canAccess = canUserAccess(to)
//   if(!canAccess) {
//     next({name: 'login'})
//   } else {
//     next()
//   }
// })


// const emitter = window.app.config.globalProperties.$emitter

// router.afterEach((to, from, failure) => {
//   console.log("router.afterEach", to, from, failure)
  
  
  
//   setTimeout(() => {
//     console.log(emitter)
//     emitter.emit("after_router", {key: "test"})
//     // const emitter = mitt()
//     // emitter.emit("after_router", {key: "test"})
//   }, 2000)
  
// })

export default router
