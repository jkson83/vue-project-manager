// Layout
import LayoutLogin from "@/components/layout/LayoutLogin.vue"
import LayoutBasic from "@/components/layout/LayoutBasic.vue"
import LayoutView from "@/components/layout/LayoutView.vue"
import LayoutPopup from "@/components/layout/LayoutPopup.vue"

//FE_MB: Membership
import FE_MB_LG_01 from "@/views/publishing/FE_MB/FE_MB_LG_01.vue"
import FE_MB_LG_01_child01 from "@/views/publishing/FE_MB/FE_MB_LG_01_child01.vue"
import FE_MB_AG_01 from "@/views/publishing/FE_MB/FE_MB_AG_01.vue"
import FE_MB_AG_02 from "@/views/publishing/FE_MB/FE_MB_AG_02.vue"
import FE_MB_AG_02_child01 from "@/views/publishing/FE_MB/FE_MB_AG_02_child01.vue"
import FE_MB_AS_01 from "@/views/publishing/FE_MB/FE_MB_AS_01.vue"
import FE_MB_AS_02 from "@/views/publishing/FE_MB/FE_MB_AS_02.vue"
import FE_MB_AS_02_child01 from "@/views/publishing/FE_MB/FE_MB_AS_02_child01.vue"
import FE_MB_AS_03 from "@/views/publishing/FE_MB/FE_MB_AS_03.vue"
import FE_MB_LG_01_child02 from "@/views/publishing/FE_MB/FE_MB_LG_01_child02.vue"
import FE_MB_ULK_01 from "@/views/publishing/FE_MB/FE_MB_ULK_01.vue"
import FE_MB_90_01 from "@/views/publishing/FE_MB/FE_MB_90_01.vue"
import FE_MB_RA_01 from "@/views/publishing/FE_MB/FE_MB_RA_01.vue"
import FE_MB_ERR_01 from "@/views/publishing/FE_MB/FE_MB_ERR_01.vue"
import FE_MB_ERR_02 from "@/views/publishing/FE_MB/FE_MB_ERR_02.vue"
import FE_MB_TC_01 from "@/views/publishing/FE_MB/FE_MB_TC_01.vue"
import FE_MB_TC_02 from "@/views/publishing/FE_MB/FE_MB_TC_02.vue"
import FE_MB_TC_04 from "@/views/publishing/FE_MB/FE_MB_TC_04.vue"

//FE_HO: 메인
import FE_HO_CO_01 from "@/views/publishing/FE_HO/FE_HO_CO_01.vue"
import FE_Common_UI_Main from "@/views/publishing/FE_HO/FE_Common_UI_Main.vue"
import FE_Popup from "@/views/publishing/FE_HO/FE_Popup.vue"
import FE_Loading from "@/views/publishing/FE_HO/FE_Loading.vue"
import FE_Loading_svg from "@/views/publishing/FE_HO/FE_Loading_svg.vue"

//FE_DS: 대시보드
import FE_DS_GC_01 from "@/views/publishing/FE_DS/FE_DS_GC_01.vue"

//FE_RP: 보고서
import FE_RP_CB_01 from "@/views/publishing/FE_RP/FE_RP_CB_01.vue"
import FE_RP_CB_02 from "@/views/publishing/FE_RP/FE_RP_CB_02.vue"
import FE_RP_CB_03 from "@/views/publishing/FE_RP/FE_RP_CB_03.vue"
import FE_RP_CB_04 from "@/views/publishing/FE_RP/FE_RP_CB_04.vue"
import FE_RP_AN_01 from "@/views/publishing/FE_RP/FE_RP_AN_01.vue"

//FE_DO: 데이터 현황
import FE_DO_DS_01 from "@/views/publishing/FE_DO/FE_DO_DS_01.vue"
import FE_DO_DS_02 from "@/views/publishing/FE_DO/FE_DO_DS_02.vue"
import FE_DO_DS_04 from "@/views/publishing/FE_DO/FE_DO_DS_04.vue"
import FE_DO_DS_04_popup from "@/views/publishing/FE_DO/FE_DO_DS_04_popup.vue"
import FE_DO_MD_01 from "@/views/publishing/FE_DO/FE_DO_MD_01.vue"
import FE_DO_CV_01 from "@/views/publishing/FE_DO/FE_DO_CV_01.vue"


//FE_CM: 커뮤니티
import FE_CM_BD_00 from "@/views/publishing/FE_CM/FE_CM_BD_00.vue"
import FE_CM_BD_01 from "@/views/publishing/FE_CM/FE_CM_BD_01.vue"
import FE_CM_BD_01_child02 from "@/views/publishing/FE_CM/FE_CM_BD_01_child02.vue"
import FE_CM_BD_02 from "@/views/publishing/FE_CM/FE_CM_BD_02.vue"
import FE_CM_NT_01 from "@/views/publishing/FE_CM/FE_CM_NT_01.vue"
import FE_CM_NT_02 from "@/views/publishing/FE_CM/FE_CM_NT_02.vue"
import FE_CM_FAQ_01 from "@/views/publishing/FE_CM/FE_CM_FAQ_01.vue"

//FE_AE: 분석 환경
import FE_AE_IF_01_1 from "@/views/publishing/FE_AE/FE_AE_IF_01_1.vue"
import FE_AE_IF_02_2 from "@/views/publishing/FE_AE/FE_AE_IF_02_2.vue"
import FE_AE_IF_02_3 from "@/views/publishing/FE_AE/FE_AE_IF_02_3.vue"
import FE_AE_DA_01 from "@/views/publishing/FE_AE/FE_AE_DA_01.vue"
import FE_AE_DA_03_6 from "@/views/publishing/FE_AE/FE_AE_DA_03_6.vue"
import FE_AE_DA_03_7 from "@/views/publishing/FE_AE/FE_AE_DA_03_7.vue"
import FE_AE_DA_03_8 from "@/views/publishing/FE_AE/FE_AE_DA_03_8.vue"
import FE_AE_DA_03_1 from "@/views/publishing/FE_AE/FE_AE_DA_03_1.vue"
import FE_AE_DA_03_2 from "@/views/publishing/FE_AE/FE_AE_DA_03_2.vue"
import FE_AE_DA_03_3 from "@/views/publishing/FE_AE/FE_AE_DA_03_3.vue"
import FE_AE_DA_03_4 from "@/views/publishing/FE_AE/FE_AE_DA_03_4.vue"
import FE_AE_DA_03_5 from "@/views/publishing/FE_AE/FE_AE_DA_03_5.vue"

//FE_MY: MY Page
import FE_MY_PA_01 from "@/views/publishing/FE_MY/FE_MY_PA_01.vue"
import FE_MY_PA_01_1 from "@/views/publishing/FE_MY/FE_MY_PA_01_1.vue"
import FE_MY_PA_01_2 from "@/views/publishing/FE_MY/FE_MY_PA_01_2.vue"
import FE_MY_PA_01_3 from "@/views/publishing/FE_MY/FE_MY_PA_01_3.vue"
import FE_MY_PA_02 from "@/views/publishing/FE_MY/FE_MY_PA_02.vue"
import FE_MY_PA_03 from "@/views/publishing/FE_MY/FE_MY_PA_03.vue"
import FE_MY_PA_04 from "@/views/publishing/FE_MY/FE_MY_PA_04.vue"
import FE_MY_PA_04_1 from "@/views/publishing/FE_MY/FE_MY_PA_04_1.vue"
import FE_MY_PA_04_2 from "@/views/publishing/FE_MY/FE_MY_PA_04_2.vue"
import FE_MY_AM_01 from "@/views/publishing/FE_MY/FE_MY_AM_01.vue"
import FE_MY_AM_02 from "@/views/publishing/FE_MY/FE_MY_AM_02.vue"
import FE_MY_AM_02_1 from "@/views/publishing/FE_MY/FE_MY_AM_02_1.vue"

//FE_ETC:메일전송 포맷 및 포털이용가이드
//import FE_ETC_FM_01 from "@/views/publishing/FE_ETC/FE_ETC_FM_01.html"
import FE_ETC_GD_01 from "@/views/publishing/FE_ETC/FE_ETC_GD_01.vue"
import FE_ETC_GD_02 from "@/views/publishing/FE_ETC/FE_ETC_GD_02.vue"
import FE_ETC_BM_01 from "@/views/publishing/FE_ETC/FE_ETC_BM_01.vue"

// Guide
import GuideComponent from "@/views/publishing/Guide/GuideComponent.vue"
import GuideForm from "@/views/publishing/Guide/GuideForm.vue"
import GuideButton from "@/views/publishing/Guide/GuideButton.vue"
import GuideTable from "@/views/publishing/Guide/GuideTable.vue"
import GuideTableWrite from "@/views/publishing/Guide/GuideTableWrite.vue"
import GuideSearchBox from "@/views/publishing/Guide/GuideSearchBox.vue"
import GuideAlertConfirm from "@/views/publishing/Guide/GuideAlertConfirm.vue"
import GuideAccordion from "@/views/publishing/Guide/GuideAccordion.vue"
import GuideModal from "@/views/publishing/Guide/GuideModal.vue"
import GuideTab from "@/views/publishing/Guide/GuideTab.vue"
import TemplateModal_pop from "@/views/publishing/Guide/TemplateModal_pop.vue"
import TemplateModal from "@/views/publishing/Guide/TemplateModal.vue"
// import GuideTooltip from "@/views/publishing/Guide/GuideTooltip.vue"


export default [
	//FE_MB: Membership: 사용자 로그인
	{
		path: '/publishing/FE_MB', 
		name: 'FE_MB_LOGIN',
		redirect: { name: "FE_MB_LG_01" },
		component: LayoutLogin,
		children: [
			{ path: "FE_MB_LG_01", name: "FE_MB_LG_01", component: FE_MB_LG_01, pageName: '사용자 로그인' },
			{ path: "FE_MB_LG_01_child01", name: "FE_MB_LG_01_child01", component: FE_MB_LG_01_child01, pageName: '사용자 로그인_분기' },
			{ path: "FE_MB_AG_01", name: "FE_MB_AG_01", component: FE_MB_AG_01, pageName: '최초 이용 동의' },
			{ path: "FE_MB_AG_02", name: "FE_MB_AG_02", component: FE_MB_AG_02, pageName: '최초 이용 동의_휴대폰번호인증' },
			{ path: "FE_MB_AG_02_child01", name: "FE_MB_AG_02_child01", component: FE_MB_AG_02_child01, pageName: '최초 이용 동의_휴대폰번호인증_분기' },
			// { path: "FE_MB_AG_03", name: "FE_MB_AG_03", component: FE_MB_AG_03, pageName: '최초 이용 동의_비밀번호설정' }, //이건 모지?
			{ path: "FE_MB_AS_01", name: "FE_MB_AS_01", component: FE_MB_AS_01, pageName: '계정정보재설정' },
			{ path: "FE_MB_AS_02", name: "FE_MB_AS_02", component: FE_MB_AS_02, pageName: '휴대전화번호 인증' },
			{ path: "FE_MB_AS_02_child01", name: "FE_MB_AS_02_child01", component: FE_MB_AS_02_child01, pageName: '휴대전화번호 인증_분기' },
			{ path: "FE_MB_AS_03", name: "FE_MB_AS_03", component: FE_MB_AS_03, pageName: '비밀번호 설정' },
			{ path: "FE_MB_LG_01_child02", name: "FE_MB_LG_01_child02", component: FE_MB_LG_01_child02, pageName: '계정 잠금 alert창' },
			{ path: "FE_MB_ULK_01", name: "FE_MB_ULK_01", component: FE_MB_ULK_01, pageName: '계정 잠금 해제' },
			{ path: "FE_MB_90_01", name: "FE_MB_90_01", component: FE_MB_90_01, pageName: '90일경과 재설정' },
			{ path: "FE_MB_RA_01", name: "FE_MB_RA_01", component: FE_MB_RA_01, pageName: '휴면계정복구' },
			{ path: "FE_MB_TC_04", name: "FE_MB_TC_04", component: FE_MB_TC_04, pageName: '약관레이어팝업페이지' },
		]
	},

	//Error
	{
		path: '/publishing/FE_MB/FE_MB_ERR_01', 
		name: 'FE_MB_ERR_01',
		component: FE_MB_ERR_01,
		pageName: '에러페이지: 로그인 전'
	},
	{
		path: '/publishing/FE_MB', 
		name: 'FE_MB_ERR_02',
		redirect: { name: "FE_MB_ERR_02" },
		component: LayoutBasic,
		children: [
			{ path: "FE_MB_ERR_02", name: "FE_MB_ERR_02", component: FE_MB_ERR_02, pageName: '에러페이지: 로그인 후' },
		]
	},

	//FE_MB_TEARMS: 약관 및 정책
	{
		path: '/publishing/FE_MB', 
		name: 'FE_MB_TEARMS',
		redirect: { name: "FE_MB_TC_01" },
		component: LayoutBasic,
		children: [
			{ path: "FE_MB_TC_01", name: "FE_MB_TC_01", component: FE_MB_TC_01, pageName: '이용 약관' },
			{ path: "FE_MB_TC_02", name: "FE_MB_TC_02", component: FE_MB_TC_02, pageName: '개인정보처리방침' },
		]
	},

	//FE_HO: UI
	{
		path: '/publishing/FE_HO/FE_Common_UI_Main', 
		name: 'FE_Common_UI_Main',
		component: FE_Common_UI_Main,
		pageName: 'Main UI'
	},
	{
		path: '/publishing/FE_HO', 
		name: 'FE_HO',
		redirect: { name: "FE_HO_CO_01" },
		component: LayoutBasic,
		children: [
			{path: "FE_HO_CO_01", name: "FE_HO_CO_01", component: FE_HO_CO_01, pageName: 'Sub UI'},
			{path: "FE_Popup", name: "FE_Popup", component: FE_Popup, pageName: 'Main Pop-up'},
			{path: "FE_Loading", name: "FE_Loading", component: FE_Loading, pageName: 'Loading'},
			{path: "FE_Loading_svg", name: "FE_Loading_svg", component: FE_Loading_svg, pageName: 'Loading'},
		]
	},

	//FE_DS: 대시보드
	{
		path: '/publishing/FE_DS', 
		name: 'FE_DS',
		redirect: { name: "FE_DS_GC_01" },
		component: LayoutBasic,
		children: [
			{path: "FE_DS_GC_01", name: "FE_DS_GC_01", component: FE_DS_GC_01, pageName: '자료실'},
		]
	},

	//FE_RP: 보고서
	{
		path: '/publishing/FE_RP', 
		name: 'FE_RP',
		redirect: { name: "FE_RP_CB_01" },
		component: LayoutBasic,
		children: [
			{ path: "FE_RP_CB_01", name: "FE_RP_CB_01", component: FE_RP_CB_01, pageName: '가명 결합 보고서' },
			{path: "FE_RP_AN_01", name: "FE_RP_AN_01", component: FE_RP_AN_01, pageName: '분석 보고서'},
		]
	},

	//VIEW: 보고서 View
	{
		path: '/publishing/FE_RP', 
		name: 'FE_RP_VIEW',
		// redirect: { name: "FE_CM_BD_01" },
		component: LayoutView,
		children: [
			{ path: "FE_RP_CB_02", name: "FE_RP_CB_02", component: FE_RP_CB_02, pageName: '가명 결합 보고서-view' },
			{ path: "FE_RP_CB_03", name: "FE_RP_CB_03", component: FE_RP_CB_03, pageName: '가명 결합 보고서-edit' },
			{ path: "FE_RP_CB_04", name: "FE_RP_CB_04", component: FE_RP_CB_04, pageName: '가명 결합 보고서-PDF Viewer' },
		] 
	},


	//FE_DO: 데이터 현황
	{
		path: '/publishing/FE_DO', 
		name: 'FE_DO',
		redirect: { name: "FE_DO_DS_01" },
		component: LayoutBasic,
		children: [
			{ path: "FE_DO_DS_01", name: "FE_DO_DS_01", component: FE_DO_DS_01, pageName: '보유 데이터 조회' },
			{ path: "FE_DO_DS_02", name: "FE_DO_DS_02", component: FE_DO_DS_02, pageName: '보유 데이터 조회' },
			{ path: "FE_DO_DS_04", name: "FE_DO_DS_04", component: FE_DO_DS_04, pageName: '보유 데이터 조회/상세팝업' },
			{ path: "FE_DO_MD_01", name: "FE_DO_MD_01", component: FE_DO_MD_01, pageName: ' 메타 데이터 조회' },
			{path: "FE_DO_CV_01", name: "FE_DO_CV_01", component: FE_DO_CV_01, pageName: '동의 현황'},
		]
	},

	{
		path: '/publishing/FE_DO', 
		name: 'FE_DO_POP',
		// redirect: { name: "FE_CM_BD_01" },
		component: LayoutPopup,
		children: [
			{ path: "FE_DO_DS_04_popup", name: "FE_DO_DS_04_popup", component: FE_DO_DS_04_popup, pageName: '보유 데이터 조회/상세팝업' },
		] 
	},

	//FE_CM: 커뮤니티
	{
		path: '/publishing/FE_CM', 
		name: 'FE_CM',
		redirect: { name: "FE_CM_BD_01" },
		component: LayoutBasic,
		children: [
			{path: "FE_CM_BD_00", name: "FE_CM_BD_00", component: FE_CM_BD_00, pageName: '자료실: 권한신청'},
			{path: "FE_CM_BD_01", name: "FE_CM_BD_01", component: FE_CM_BD_01, pageName: '자료실'},
			{path: "FE_CM_BD_01_child02", name: "FE_CM_BD_01_child02", component: FE_CM_BD_01_child02, pageName: '자료실: 검색결과'},
			{path: "FE_CM_NT_01", name: "FE_CM_NT_01", component: 	FE_CM_NT_01, pageName: '공지사항'},
			{path: "FE_CM_FAQ_01", name: "FE_CM_FAQ_01", component: 	FE_CM_FAQ_01, pageName: 'FAQ'},
		]
	},

	//VIEW: 커뮤니티 View
	{
		path: '/publishing/FE_CM', 
		name: 'FE_CM_VIEW',
		// redirect: { name: "FE_CM_BD_01" },
		component: LayoutView,
		children: [
			{path: "FE_CM_BD_02", name: "FE_CM_BD_02", component: FE_CM_BD_02, pageName: '자료실: View'},
			{path: "FE_CM_NT_02", name: "FE_CM_NT_02", component: 	FE_CM_NT_02, pageName: '공지사항: View'},
		]
	},

	//FE_AE: 분석 환경
	{
		path: '/publishing/FE_AE', 
		name: 'FE_AE',
		redirect: { name: "FE_AE_IF_01_1" },
		component: LayoutBasic,
		children: [
			{path: "FE_AE_IF_01_1", name: "FE_AE_IF_01_1", component: FE_AE_IF_01_1, pageName: '프로젝트 조회'},
			{path: "FE_AE_IF_02_2", name: "FE_AE_IF_02_2", component: FE_AE_IF_02_2, pageName: '프로젝트 조회/데이터권한(Tab)'},
			{path: "FE_AE_IF_02_3", name: "  ", component: FE_AE_IF_02_3, pageName: '프로젝트 조회 / 데이터 접근 권한 신청 (팝업)'},
			{path: "FE_AE_DA_01", name: "FE_AE_DA_01", component: FE_AE_DA_01, pageName: '데이터 결재 관리/발신결재'},
			{path: "FE_AE_DA_03_6", name: "FE_AE_DA_03_6", component: FE_AE_DA_03_6, pageName: '데이터 결재 관리/반려 사유 작성 (팝업)'},
			{path: "FE_AE_DA_03_7", name: "FE_AE_DA_03_7", component: FE_AE_DA_03_7, pageName: '데이터 결재 관리/전체 결재자 정보(팝업)'},
			{path: "FE_AE_DA_03_8", name: "FE_AE_DA_03_8", component: FE_AE_DA_03_8, pageName: '반출 신청 파일 미리보기 (팝업)'},
		]
	},

	//VIEW: 분석 환경
	{
		path: '/publishing/FE_AE', 
		name: 'FE_AE_VIEW',
		// redirect: { name: "FE_CM_BD_01" },
		component: LayoutView,
		children: [
			{path: "FE_AE_DA_03_1", name: "FE_AE_DA_03_1", component: FE_AE_DA_03_1, pageName: '수신 결재/데이터 접근 권한 결재 View'},
			{path: "FE_AE_DA_03_2", name: "FE_AE_DA_03_2", component: FE_AE_DA_03_2, pageName: '수신 결재/멤버 추가 결재 View'},
			{path: "FE_AE_DA_03_3", name: "FE_AE_DA_03_3", component: FE_AE_DA_03_3, pageName: '수신 결재/기간 연장 신청 결재 View'},
			{path: "FE_AE_DA_03_4", name: "FE_AE_DA_03_4", component: FE_AE_DA_03_4, pageName: '수신 결재/오너 위임 신청 결재 View'},
			{path: "FE_AE_DA_03_5", name: "FE_AE_DA_03_5", component: FE_AE_DA_03_5, pageName: '수신 결재/파일 반출 신청 결재 View'},
		]
	},


	//FE_MY: MY Page
	{
		path: '/publishing/FE_MY', 
		name: 'FE_MY',
		redirect: { name: "FE_MY_PA_01" },
		component: LayoutBasic,
		children: [
			{path: "FE_MY_PA_01", name: "FE_MY_PA_01", component: FE_MY_PA_01, pageName: '마이 홈'},
			{path: "FE_MY_PA_01_1", name: "FE_MY_PA_01_1", component: FE_MY_PA_01_1, pageName: '마이 홈/계정 비밀번호 변경'},
			{path: "FE_MY_PA_01_2", name: "FE_MY_PA_01_2", component: FE_MY_PA_01_2, pageName: '마이 홈/휴대전화번호 변경'},
			{path: "FE_MY_PA_01_3", name: "FE_MY_PA_01_3", component: FE_MY_PA_01_3, pageName: '마이 홈/보유 이용 권한 신청'},
			{path: "FE_MY_PA_02", name: "FE_MY_PA_02", component: FE_MY_PA_02, pageName: '알림함'},
			{path: "FE_MY_PA_03", name: "FE_MY_PA_03", component: FE_MY_PA_03, pageName: '내 문서'},
			{path: "FE_MY_PA_04", name: "FE_MY_PA_04", component: FE_MY_PA_04, pageName: '1:1문의/List'},
			{path: "FE_MY_AM_01", name: "FE_MY_AM_01", component: FE_MY_AM_01, pageName: '서비스 결재 관리/발신 결재'},
			{path: "FE_MY_AM_02", name: "FE_MY_AM_02", component: FE_MY_AM_02, pageName: '서비스 결재 관리/수신 결재'},
		]
	},

	{
		path: '/publishing/FE_MY', 
		name: 'FE_MY_VIEW',
		// redirect: { name: "FE_MY_BD_01" },
		component: LayoutView,
		children: [
			{path: "FE_MY_PA_04_1", name: "FE_MY_PA_04_1", component: FE_MY_PA_04_1, pageName: '1:1문의/View'},
			{path: "FE_MY_PA_04_2", name: "FE_MY_PA_04_2", component: FE_MY_PA_04_2, pageName: '1:1문의/Edit'},
			{path: "FE_MY_AM_02_1", name: "FE_MY_AM_02_1", component: FE_MY_AM_02_1, pageName: '서비스 결재 관리/수신 결재/View'},
		]
	},


	//FE_ETC:메일전송 포맷 및 포털이용가이드
	{
		path: '/publishing/FE_ETC', 
		name: 'FE_ETC',
		redirect: { name: "FE_ETC_GD_01" },
		component: LayoutBasic,
		children: [
			{ path: "FE_ETC_GD_01", name: "FE_ETC_GD_01", component: FE_ETC_GD_01, pageName: '포털이용가이드' },
			{ path: "FE_ETC_BM_01", name: "FE_ETC_BM_01", component: FE_ETC_BM_01, pageName: '즐겨찾기 Popup' },
		]
	},

	//VIEW: 포털이용가이드 View
	{
		path: '/publishing/FE_ETC', 
		name: 'FE_ETC_View',
		// redirect: { name: "FE_CM_BD_01" },
		component: LayoutView,
		children: [
			{ path: "FE_ETC_GD_02", name: "FE_ETC_GD_02", component: FE_ETC_GD_02, pageName: '포털이용가이드_view' },
			//{ path: "FE_ETC_FM_01", name: "FE_ETC_FM_01", component: FE_ETC_FM_01, pageName: '메일 전송 포맷' },
		] 
	},


	//Guide
	{
		path: '/publishing/Guide', 
		name: 'Guide',
		redirect: { name: "GuideComponent" },
		component: LayoutBasic,
		meta: { 
			auth: false,
			logging: false,
			pageName: '샘플',
		},
		children: [
			{path: "GuideComponent", name: "GuideComponent", component: GuideComponent, pageName: '컴포넌트가이드'},
			{path: "GuideForm", name: "GuideForm", component: GuideForm, pageName: '컴포넌트가이드'},
			{path: "GuideButton", name: "GuideButton", component: GuideButton, pageName: '버튼'},
			{path: "GuideTable", name: "GuideTable", component: GuideTable, pageName: '상세페이지'},
			{path: "GuideTableWrite", name: "GuideTableWrite", component: GuideTableWrite, pageName: '등록/수정페이지'},
			{path: "GuideSearchBox", name: "GuideSearchBox", component: GuideSearchBox, pageName: 'SearchBox'},
			{path: "GuideModal", name: "GuideModal", component: GuideModal, pageName: 'Modal'},
			{path: "GuideAlertConfirm", name: "GuideAlertConfirm", component: GuideAlertConfirm, pageName: 'AlertConfirm'},
			{path: "GuideAccordion", name: "GuideAccordion", component: GuideAccordion, pageName: 'Accordion'},
			{path: "GuideTab", name: "GuideTab", component: GuideTab, pageName: 'Tab'},
			// {path: "GuideTooltip", name: "GuideTooltip", component: GuideTooltip, pageName: '툴팁안내'},`

			//Template
			{path: "TemplateModal_pop", name: "TemplateModal_pop", component: TemplateModal_pop, pageName: 'TemplateModal_pop'},
			{path: "TemplateModal", name: "TemplateModal", component: TemplateModal, pageName: 'TemplateModal'},
		]
	},
]
