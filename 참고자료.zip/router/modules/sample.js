
export default  [
  { 
    path: '/sample/sample', 
    name: 'sample',
    component: () => import('@/views/sample/Sample'),
    meta: { 
      auth: false,
      logging: true,
      pageName: '샘플',
    }
  },
]
